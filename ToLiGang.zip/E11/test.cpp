#include<iostream>
using namespace std;
//#include"../zjslib/zjslib.h"



int main(){
	
}
