int main()
{
	float a = 2.999;
	return float(a);
}
