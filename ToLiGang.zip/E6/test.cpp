#include <iostream>
#include <string.h>
#include<stdlib.h>
using namespace std;


int main()
{
	char a[200];
	for(int i=0;i<200;i++){
		printf("%d",a[i]);
	}
}
